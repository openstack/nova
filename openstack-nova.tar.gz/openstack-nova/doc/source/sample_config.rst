==========================
Nova Configuration Options
==========================

The following is a sample Nova configuration for adaptation and use. It is
auto-generated from Nova when this documentation is built, so
if you are having issues with an option, please compare your version of
Nova with the version of this documentation.

The sample configuration can also be viewed in `file form <_static/nova.conf.sample>`_.

.. literalinclude:: _static/nova.conf.sample
